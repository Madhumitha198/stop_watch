// DIGITAL CLOCK
function updateDigitalClock() {
  const now = new Date();
  document.getElementById('clock').textContent = now.toLocaleTimeString();
}
setInterval(updateDigitalClock, 1000);
updateDigitalClock();

// ANALOG CLOCK
function updateAnalogClock() {
  const now = new Date();
  const seconds = now.getSeconds();
  const minutes = now.getMinutes();
  const hours = now.getHours() % 12;

  const secondDeg = seconds * 6; // 360/60
  const minuteDeg = minutes * 6 + seconds * 0.1; // smooth movement
  const hourDeg = hours * 30 + minutes * 0.5;

  document.getElementById('second-hand').style.transform = `rotate(${secondDeg}deg)`;
  document.getElementById('minute-hand').style.transform = `rotate(${minuteDeg}deg)`;
  document.getElementById('hour-hand').style.transform = `rotate(${hourDeg}deg)`;
}
setInterval(updateAnalogClock, 1000);
updateAnalogClock();

// STOPWATCH
let stopwatchInterval = null;
let stopwatchTime = 0;
let stopwatchRunning = false;
const lapsList = document.getElementById('laps');
const historyList = document.getElementById('history');

function formatTime(seconds) {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${String(hrs).padStart(2,'0')}:${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
}

function updateStopwatchDisplay() {
  document.getElementById('stopwatch').textContent = formatTime(stopwatchTime);
}

function startStopwatch() {
  if (stopwatchRunning) return;
  stopwatchRunning = true;
  stopwatchInterval = setInterval(() => {
    stopwatchTime++;
    updateStopwatchDisplay();
  }, 1000);
}

function stopStopwatch() {
  if (!stopwatchRunning) return;
  stopwatchRunning = false;
  clearInterval(stopwatchInterval);
  // Save session to history on stop
  addHistoryEntry(stopwatchTime);
}

function resetStopwatch() {
  stopwatchRunning = false;
  clearInterval(stopwatchInterval);
  stopwatchTime = 0;
  updateStopwatchDisplay();
  lapsList.innerHTML = '';
}

function recordLap() {
  if (!stopwatchRunning) return;
  const lapTime = formatTime(stopwatchTime);
  const lapCount = lapsList.children.length + 1;
  const li = document.createElement('li');
  li.textContent = `Lap ${lapCount}: ${lapTime}`;
  lapsList.appendChild(li);
}

function addHistoryEntry(time) {
  const li = document.createElement('li');
  const now = new Date();
  li.textContent = `${now.toLocaleString()}: ${formatTime(time)}`;
  historyList.appendChild(li);
  // Optional: save history to localStorage here
}

// COUNTDOWN TIMER
let countdownInterval = null;

function startCountdown() {
  let seconds = parseInt(document.getElementById('countdownInput').value, 10);
  if (isNaN(seconds) || seconds <= 0) {
    alert('Please enter a valid number of seconds.');
    return;
  }
  clearInterval(countdownInterval);

  function updateCountdown() {
    if (seconds <= 0) {
      clearInterval(countdownInterval);
      document.getElementById('countdownDisplay').textContent = '00:00';
      alert('Countdown finished!');
      playCustomSound();
      return;
    }
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    document.getElementById('countdownDisplay').textContent = `${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
    seconds--;
  }

  updateCountdown();
  countdownInterval = setInterval(updateCountdown, 1000);
}

// ALARM CLOCK
let alarmTimeout = null;
function setAlarm() {
  const alarmTime = document.getElementById('alarmTime').value;
  if (!alarmTime) {
    alert('Please select a valid alarm time.');
    return;
  }
  if (alarmTimeout) clearTimeout(alarmTimeout);
  const now = new Date();
  const alarmDateTime = new Date();
  const [hours, minutes] = alarmTime.split(':').map(Number);
  alarmDateTime.setHours(hours, minutes, 0, 0);
  if (alarmDateTime <= now) {
    alarmDateTime.setDate(alarmDateTime.getDate() + 1); // next day
  }
  const diff = alarmDateTime - now;
  document.getElementById('alarmStatus').textContent = `Alarm set for ${alarmDateTime.toLocaleTimeString()}`;
  alarmTimeout = setTimeout(() => {
    alert('Alarm ringing!');
    playCustomSound();
    document.getElementById('alarmStatus').textContent = 'Alarm finished.';
  }, diff);
}

// WORLD CLOCK
function updateWorldClocks() {
  const now = new Date();
  const options = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
  // New York (UTC-4 or UTC-5)
  const nyTime = now.toLocaleTimeString('en-US', { ...options, timeZone: 'America/New_York' });
  // London (UTC+1 or UTC+0)
  const londonTime = now.toLocaleTimeString('en-GB', { ...options, timeZone: 'Europe/London' });
  // Tokyo (UTC+9)
  const tokyoTime = now.toLocaleTimeString('en-JP', { ...options, timeZone: 'Asia/Tokyo' });

  document.getElementById('ny-time').textContent = nyTime;
  document.getElementById('london-time').textContent = londonTime;
  document.getElementById('tokyo-time').textContent = tokyoTime;
}
setInterval(updateWorldClocks, 1000);
updateWorldClocks();

// THEME TOGGLE (Dark/Light Mode)
const themeToggle = document.getElementById('themeToggle');
themeToggle.addEventListener('change', () => {
  if (themeToggle.checked) {
    document.body.classList.add('dark');
    localStorage.setItem('theme', 'dark');
  } else {
    document.body.classList.remove('dark');
    localStorage.setItem('theme', 'light');
  }
});

// Load saved theme preference
(function loadTheme() {
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    document.body.classList.add('dark');
    themeToggle.checked = true;
  }
})();

// VOICE CONTROLLED STOPWATCH
let recognition = null;
function startVoiceRecognition() {
  if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
    alert('Your browser does not support Speech Recognition API.');
    return;
  }
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.start();
  document.getElementById('voiceStatus').textContent = 'Listening...';

  recognition.onresult = (event) => {
    const command = event.results[0][0].transcript.toLowerCase();
    document.getElementById('voiceStatus').textContent = `You said: "${command}"`;
    if (command.includes('start stopwatch')) startStopwatch();
    else if (command.includes('stop stopwatch')) stopStopwatch();
    else if (command.includes('reset stopwatch')) resetStopwatch();
    else if (command.includes('lap stopwatch')) recordLap();
    else document.getElementById('voiceStatus').textContent = 'Command not recognized.';
  };

  recognition.onerror = (event) => {
    document.getElementById('voiceStatus').textContent = `Error occurred: ${event.error}`;
  };

  recognition.onend = () => {
    // Auto restart for continuous commands can be added here
  };
}

// FITNESS INTERVAL TIMER
let fitnessInterval = null;
function startFitnessTimer() {
  let workSeconds = parseInt(document.getElementById('workTime').value, 10);
  let restSeconds = parseInt(document.getElementById('restTime').value, 10);
  let rounds = parseInt(document.getElementById('rounds').value, 10);

  if ([workSeconds, restSeconds, rounds].some(n => isNaN(n) || n <= 0)) {
    alert('Please enter valid positive numbers for work, rest, and rounds.');
    return;
  }

  let currentRound = 1;
  let isWork = true;
  let timeLeft = workSeconds;
  const statusDiv = document.getElementById('fitnessStatus');
  clearInterval(fitnessInterval);

  statusDiv.textContent = `Round ${currentRound} - Work: ${timeLeft}s`;
  playCustomSound();

  fitnessInterval = setInterval(() => {
    timeLeft--;
    statusDiv.textContent = `Round ${currentRound} - ${isWork ? 'Work' : 'Rest'}: ${timeLeft}s`;
    if (timeLeft <= 0) {
      playCustomSound();
      if (isWork) {
        isWork = false;
        timeLeft = restSeconds;
      } else {
        currentRound++;
        if (currentRound > rounds) {
          statusDiv.textContent = 'Workout complete!';
          clearInterval(fitnessInterval);
          return;
        }
        isWork = true;
        timeLeft = workSeconds;
      }
    }
  }, 1000);
}

// CUSTOM BACKGROUND COLOR
function changeBackgroundColor(color) {
  document.body.style.backgroundColor = color;
}

// CUSTOM SOUND
let customAudio = null;
function loadCustomSound(event) {
  const file = event.target.files[0];
  if (!file) return;
  const url = URL.createObjectURL(file);
  customAudio = new Audio(url);
}

function playCustomSound() {
  if (customAudio) {
    customAudio.play().catch(() => {});
  }
}
